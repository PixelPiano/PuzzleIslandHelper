namespace Celeste.Mod.PuzzleIslandHelper {
    public class PianoModuleSettings : EverestModuleSettings {

    }
}
