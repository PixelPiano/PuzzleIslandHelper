using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monocle;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Celeste.Mod.PuzzleIslandHelper.Entities
{
    public class LHLData
    {
        public Vector2 Position;
        public float Rotation;
        public Vector2 Origin;
        public Vector2 CollisionPosition;
        public Vector2 LightPosition;
        public LHLData(Vector2 position, Vector2 collisionPosition, Vector2 origin, float rotation, Vector2 lightPosition)
        {
            Position = position;
            Rotation = rotation;
            Origin = origin;
            CollisionPosition = collisionPosition;
            LightPosition = lightPosition;

        }
    }
    [CustomEntity("PuzzleIslandHelper/LabLightRenderer")]
    [Tracked]
    public class LabLightRenderer : Entity
    {
        public VertexPositionColor[] vertices = new VertexPositionColor[3];
        private Level level;
        public bool Broken;
        public float PowerScalar = 1;
        private static VirtualRenderTarget _Target;
        public static VirtualRenderTarget Target => _Target ??= VirtualContent.CreateRenderTarget("LampTarget", 320, 180);

        public override void Removed(Scene scene)
        {
            base.Removed(scene);
            _Target?.Dispose();
            _Target = null;
        }
        public LabLightRenderer(Scene scene) : base(Vector2.Zero)
        {
            level = scene as Level;
            Depth = -8001;
            Add(new BeforeRenderHook(BeforeRender));
            Tag |= Tags.TransitionUpdate | Tags.Global;
            //Add(new CustomBloom(BloomRender));
        }
        public override void Update()
        {
            base.Update();
            level = Engine.Scene as Level;
        }
        public LabLightRenderer(EntityData data, Vector2 offset) : base(data.Position + offset)
        {
        }
        public void BloomRender()
        {
            if (vertices.Length > 0 && !Broken)
            {
                foreach (LabHangingLamp lamp in level.Tracker.GetEntities<LabHangingLamp>())
                {
                    if (!lamp.Broken)
                    {
                        lamp.vertices[0].Color = Color.LightYellow * lamp.Opacity * lamp.FlickerScalar * PowerScalar;
                        PowerScalar = PianoModule.Session.RestoredPower && !lamp.FixedOpacity ? 0.5f : 0.7f;
                        GFX.DrawVertices(level.Camera.Matrix, lamp.vertices, lamp.vertices.Length);
                    }
                }
            }
        }
        public void BeforeRender()
        {
            if (!PianoModule.Session.RestoredPower)
            {
                Engine.Graphics.GraphicsDevice.SetRenderTarget(Target);
                Engine.Graphics.GraphicsDevice.Clear(Color.Transparent);
                Draw.SpriteBatch.Begin();
                BloomRender();
                Draw.SpriteBatch.End();
            }
        }
        public override void Render()
        {
            base.Render();
            if (!PianoModule.Session.RestoredPower)
            {
                Draw.SpriteBatch.Draw(Target, level.Camera.Position, Color.White);
            }
        }
    }
    [CustomEntity("PuzzleIslandHelper/LabHangingLamp")]
    [Tracked]
    public class LabHangingLamp : Entity
    {
        public bool FixedOpacity;
        public float FlickerScalar = 1;
        private bool Collided;
        public float Opacity;
        public readonly int Length;
        private List<Image> images = new List<Image>();
        private BloomPoint bloom;
        private VertexLight light;
        private float speed;
        private float rotation;
        private float soundDelay;
        private SoundSource sfx;
        public Image Lamp;
        public Actor Head;
        public bool Broken;
        public bool Falling;
        private float Degradation;
        private float BreakingPoint = 2;
        private int WearAndTearGrade = 0;
        private float MaxSpeed = 20;
        private float SpeedMult = 1;
        private Vector2 LampSpeed;
        private EntityID id;
        private LHLData LampData;
        private float LastRotation;
        private bool HomeRun;

        public VertexPositionColor[] vertices = new VertexPositionColor[3];
        private Level level;

        public LabHangingLamp(Vector2 position, int length, EntityID id, EntityData data)
        {
            Tag |= Tags.TransitionUpdate;
            this.id = id;
            Opacity = data.Float("alpha", 1);
            FixedOpacity = data.Bool("staticOpacity");
            if (PianoModule.Session.BrokenLamps.TryGetValue(id, out LHLData value))
            {
                LampData = value;
                Broken = true;
                Falling = true;
            }
            Position = position + Vector2.UnitX * 4f;
            Length = Math.Max(16, length);
            //Depth = 2000;
            Depth = -1;
            MTexture mTexture = GFX.Game["objects/hanginglamp"];
            Image image;
            for (int i = 0; i < Length - 8; i += 8)
            {
                Add(image = new Image(mTexture.GetSubtexture(0, 8, 8, 8)));
                image.Origin.X = 4f;
                image.Origin.Y = -i;
                images.Add(image);
            }

            Add(image = new Image(mTexture.GetSubtexture(0, 0, 8, 8)));
            image.Origin.X = 4f;
            images.Add(image);


            Add(Lamp = new Image(GFX.Game["objects/PuzzleIslandHelper/hangingLamp"]));
            Add(bloom = new BloomPoint(Vector2.UnitY * (Length - 4), 1f * Opacity, 10f));
            Add(light = new VertexLight(Color.White, 0.5f * Opacity, 10, 20));
            if (!Broken)
            {
                Lamp.Origin.X = 4f;
                Lamp.Position.X--;
                Lamp.Origin.Y = -(Length - 8);
            }
            else if (LampData.Position == Vector2.Zero)
            {
                Lamp.Visible = false;
                bloom.Visible = false;
                light.Visible = false;
            }
            else
            {
                Lamp.Origin = LampData.Origin;
                Lamp.Position = LampData.Position;
                Lamp.Rotation = LampData.Rotation;
                light.Position = LampData.LightPosition;
            }

            if (Lamp.Visible)
            {
                images.Add(Lamp);
            }

            Add(sfx = new SoundSource());
            Collider = new Hitbox(8f, Length, -4f);
        }

        public LabHangingLamp(EntityData e, Vector2 position, EntityID id)
            : this(e.Position + position, Math.Max(16, e.Height), id, e)
        {
        }
        private IEnumerator Flicker(float delay)
        {
            while (!Collided)
            {
                FlickerScalar = 0.5f;
                yield return delay;
                if (Collided)
                {
                    yield break;
                }
                FlickerScalar = 0;
                yield return delay;
            }
            FlickerScalar = 0;
            yield return null;
        }
        private IEnumerator Fall()
        {
            if (Broken)
            {
                yield break;
            }
            Celeste.Freeze(0.05f);
            Lamp.CenterOrigin();
            Lamp.Position.Y += Length - 8;
            Head.Position = Lamp.RenderPosition;
            Falling = true;
            Collider.Height -= 8;
            Add(new Coroutine(Flicker(0.1f)));
            while (!Collided)
            {
                LampSpeed.Y = Calc.Min(MaxSpeed, LampSpeed.Y + Engine.DeltaTime * SpeedMult);
                SpeedMult += 0.3f;
                Head.MoveH(LampSpeed.X, OnCollideH);
                Head.MoveV(LampSpeed.Y, OnCollideV);
                Lamp.Position = Head.Position - Position + new Vector2(4, 6);
                HandleVertices();
                bloom.Position = Head.Position;
                light.Position = Head.Position;
                if (HomeRun)
                {
                    level.Camera.Position = Head.Position - new Vector2(160, 90);
                }
                yield return null;
            }
            light.Visible = false;
            if (HomeRun)
            {
                Add(new Coroutine(HoldCamera()));
            }
            if (!PianoModule.Session.BrokenLamps.ContainsKey(id))
            {
                Vector2 abs = Lamp.Position + Position;
                if (abs.X < level.LevelOffset.X || abs.X > level.LevelOffset.X + level.Bounds.Width
                || abs.Y > level.LevelOffset.Y + level.Bounds.Height)
                {
                    Lamp.Visible = false;
                    PianoModule.Session.BrokenLamps.Add(id, new LHLData(Vector2.Zero, Vector2.Zero, Vector2.Zero, 0, Vector2.Zero));
                }
                else
                {
                    PianoModule.Session.BrokenLamps.Add(id, new LHLData(Lamp.Position, Head.Position, Lamp.Origin, Lamp.Rotation, light.Position));
                }
            }
            Broken = true;
            yield return null;
        }
        private void OnCollideH(CollisionData data)
        {
            if (LampSpeed.X > 20)
            {
                Collided = true;
            }
            else
            {
                LampSpeed.X = -LampSpeed.X * 0.7f;
            }
        }
        private void OnCollideV(CollisionData data)
        {
            if (data.Direction.Y == 1)
            {
                Collided = true;
            }
            else
            {
                LampSpeed.Y = 1;
            }
        }
        public override void Update()
        {
            #region Lamp
            base.Update();
            if (Broken)
            {
                Lamp.Texture = GFX.Game["objects/PuzzleIslandHelper/hangingLampBroken"];
                Lamp.Position = Head.Position - Position + new Vector2(4, 6);
            }
            if (!Falling && !Broken)
            {
                Head.Position.Y = Position.Y + (Length - 8);
            }
            soundDelay -= Engine.DeltaTime;
            Player entity = Scene.Tracker.GetEntity<Player>();
            if (entity != null && Collider.Collide(entity))
            {
                speed = (0f - entity.Speed.X) * 0.005f * ((entity.Y - Y) / Length);
                if (!(Falling || Broken))
                {
                    LampSpeed.X = entity.Speed.X / 100;
                    LampSpeed.Y = entity.Speed.Y / 200;
                }
                if (Math.Abs(speed) < 0.1f)
                {
                    speed = 0f;
                }
                else if (soundDelay <= 0f)
                {
                    sfx.Play("event:/game/02_old_site/lantern_hit");
                    soundDelay = 0.25f;

                    if (!Falling && !Broken)
                    {
                        WearAndTearGrade++;
                        Degradation += (Math.Abs(entity.Speed.X) + Math.Abs(entity.Speed.Y) + WearAndTearGrade) * 0.005f;
                        if (Degradation > BreakingPoint)
                        {
                            Add(new Coroutine(Fall()));
                        }
                    }
                }
            }

            float num = Math.Sign(rotation) == Math.Sign(speed) ? 8f : 6f;
            if (Math.Abs(rotation) < 0.5f)
            {
                num *= 0.5f;
            }
            if (Math.Abs(rotation) < 0.25f)
            {
                num *= 0.5f;
            }

            float value = rotation;
            speed += -Math.Sign(rotation) * num * Engine.DeltaTime;
            rotation += speed * Engine.DeltaTime;
            rotation = Calc.Clamp(rotation, -0.4f, 0.4f);
            if (Math.Abs(rotation) < 0.02f && Math.Abs(speed) < 0.2f)
            {
                rotation = speed = 0f;
            }
            else if (Math.Sign(rotation) != Math.Sign(value) && soundDelay <= 0f && Math.Abs(speed) > 0.5f)
            {
                sfx.Play("event:/game/02_old_site/lantern_hit");
                soundDelay = 0.25f;
            }

            if (!Falling && !Broken)
            {
                LastRotation = rotation;
            }
            else if (Falling)
            {
                LastRotation += 0.1f;
            }

            foreach (Image image in images)
            {
                if (image == Lamp)
                {
                    if (!Broken)
                    {
                        Lamp.Rotation = LastRotation;
                    }
                }
                else
                {
                    image.Rotation = rotation;
                }
            }

            Vector2 vector = Calc.AngleToVector(rotation + (float)Math.PI / 2f, Length - 4f);
            if (!Falling && !Broken)
            {
                light.Position = bloom.Position = vector;
            }
            sfx.Position = vector;
            #endregion
            if (!PianoModule.Session.RestoredPower)
            {
                HandleVertices();
            }
            else
            {
                bloom.Visible = false;
            }
        }
        private void HandleVertices()
        {
            if (Head is null || Broken) return;
            float deg = Lamp.Rotation.ToDeg();
            Vector2 center = !Falling ? Position + Lamp.Position : Head.Position + Vector2.One * 4;
            vertices[0].Position = new Vector3(RotatePoint(Head.Position + new Vector2(4, 6), center, deg), 0);
            Vector2 top = vertices[0].Position.XY();
            vertices[1].Position = new Vector3(RotatePoint(top + Vector2.UnitX * 80, top, 120 + deg), 0);
            vertices[2].Position = new Vector3(RotatePoint(top + Vector2.UnitX * 80, top, 60 + deg), 0);
        }
        public override void Render()
        {
            foreach (Image image in Components.GetAll<Image>())
            {
                if (image != Lamp || Lamp.Visible)
                {
                    image.DrawOutline();
                }
            }
            base.Render();
        }

        public override void Added(Scene scene)
        {
            base.Added(scene);
            level = scene as Level;
            Vector2 pos = !Broken ? new Vector2(Position.X - 4, Position.Y + Length - 8) : LampData.CollisionPosition;
            scene.Add(Head = new Actor(pos));
            Head.Collider = new Hitbox(8, 8);
            Head.Add(new StaticMover());
        }
        public override void Awake(Scene scene)
        {
            base.Awake(scene);
            if (PianoUtils.SeekController<LabLightRenderer>(scene) == null)
            {
                scene.Add(new LabLightRenderer(scene));
            }
            HandleVertices();
            vertices[0].Color = Color.White;
        }

        private IEnumerator HoldCamera()
        {
            for (int i = 0; i < 300; i++)
            {
                level.Camera.Position = Position + Lamp.Position - new Vector2(160, 90);
                yield return null;
            }
        }
        static Vector2 RotatePoint(Vector2 pointToRotate, Vector2 centerPoint, double angleInDegrees)
        {
            double angleInRadians = angleInDegrees * (Math.PI / 180);
            double cosTheta = Math.Cos(angleInRadians);
            double sinTheta = Math.Sin(angleInRadians);
            return new Vector2
            {
                X =
                    (int)
                    (cosTheta * (pointToRotate.X - centerPoint.X) -
                    sinTheta * (pointToRotate.Y - centerPoint.Y) + centerPoint.X),
                Y =
                    (int)
                    (sinTheta * (pointToRotate.X - centerPoint.X) +
                    cosTheta * (pointToRotate.Y - centerPoint.Y) + centerPoint.Y)
            };
        }
    }
    public static class VecHelper
    {
        public static Vector2 RotatePoint(Vector2 pointToRotate, Vector2 centerPoint, double angleInDegrees)
        {
            double angleInRadians = angleInDegrees * (Math.PI / 180);
            double cosTheta = Math.Cos(angleInRadians);
            double sinTheta = Math.Sin(angleInRadians);
            return new Vector2
            {
                X =
                    (int)
                    (cosTheta * (pointToRotate.X - centerPoint.X) -
                    sinTheta * (pointToRotate.Y - centerPoint.Y) + centerPoint.X),
                Y =
                    (int)
                    (sinTheta * (pointToRotate.X - centerPoint.X) +
                    cosTheta * (pointToRotate.Y - centerPoint.Y) + centerPoint.Y)
            };
        }
        public static Vector2 XZ(this Vector3 vector3) => new Vector2(vector3.X, vector3.Z)
        {
        };
        public static Vector2 XY(this Vector3 vector3) => new Vector2(vector3.X, vector3.Y)
        {
        };
        public static Vector2 YZ(this Vector3 vector3) => new Vector2(vector3.Y, vector3.Z)
        {
        };
        public static Vector2 XX(this Vector3 vector3) => new Vector2(vector3.X, vector3.X)
        {
        };
        public static Vector2 YY(this Vector3 vector3) => new Vector2(vector3.Y, vector3.Y)
        {
        };
        public static Vector2 ZZ(this Vector3 vector3) => new Vector2(vector3.Z, vector3.Z)
        {
        };
    }
}