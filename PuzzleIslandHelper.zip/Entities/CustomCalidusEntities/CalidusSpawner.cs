﻿using Monocle;
using Celeste.Mod.Entities;

namespace Celeste.Mod.PuzzleIslandHelper.Entities.CustomCalidusEntities
{
    [CustomEntity("PuzzleIslandHelper/CalidusSpawner")]
    [Tracked]
    public class CalidusSpawner : Entity
    {

    }
}
