﻿using Monocle;
using Celeste.Mod.Entities;

namespace Celeste.Mod.PuzzleIslandHelper.Entities
{

    [CustomEntity("PuzzleIslandHelper/BlipTransitionController")]
    [Tracked]
    public class BlipTransitionController : Entity
    {

    }
}