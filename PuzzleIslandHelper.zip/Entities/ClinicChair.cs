﻿using Celeste.Mod.Entities;
using Monocle;

namespace Celeste.Mod.PuzzleIslandHelper.Entities
{

    [CustomEntity("PuzzleIslandHelper/ClinicChair")]
    [Tracked]
    public class ClinicChair : Entity
    {
    }
}