﻿using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monocle;
using System;

namespace Celeste.Mod.PuzzleIslandHelper.Entities
{
    //[Tracked]
    //[CustomEntity("PuzzleIslandHelper/WipEntity")]
    public class WipEntity : Entity
    {

    }
}