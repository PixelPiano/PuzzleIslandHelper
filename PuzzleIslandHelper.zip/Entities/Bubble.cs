//PuzzleIslandHelper.CustomWater
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Monocle;
using System;
using System.Collections;

namespace Celeste.Mod.PuzzleIslandHelper.Entities
{
    [Tracked]
    public class BubbleParticleSystem : ParticleSystem
    {
        public BubbleParticleSystem(int depth, int maxParticles) : base(depth, maxParticles)
        {
        }
    }
    [CustomEntity("PuzzleIslandHelper/Bubble")]
    [Tracked]
    public class Bubble : Actor
    {
        public enum BubbleType
        {
            FloatDown,
            Straight,
            FullControl
        }
        private ParticleType P_Trail = new ParticleType
        {
            Source = GFX.Game["objects/PuzzleIslandHelper/particles/bubbleSmall"],
            Size = 0.8f,
            SizeRange = 0.3f,
            SpeedMin = 20,
            SpeedMax = 40,
            Direction = 90f.ToRad(),
            DirectionRange = 15f.ToRad(),
            LifeMin = 1f,
            LifeMax = 2f,
            SpeedMultiplier = 0.6f,
            FadeMode = ParticleType.FadeModes.Late,
            Friction = 0.1f,
            Acceleration = new Vector2(2, -10),
            ScaleOut = true

        };
        private ParticleType P_Jump = new ParticleType
        {
            Source = GFX.Game["objects/PuzzleIslandHelper/particles/bubbleSmall"],
            Size = 1f,
            SpeedMin = 100,
            SpeedMax = 100,
            LifeMin = 0.5f,
            LifeMax = 1f,
            SpeedMultiplier = 1.4f,
            FadeMode = ParticleType.FadeModes.Late,
            Friction = 0.1f,
            ScaleOut = true
        };
        private ParticleType P_Pop = new ParticleType
        {
            Source = GFX.Game["objects/PuzzleIslandHelper/particles/bubbleSmall"],
            Size = 1f,
            SizeRange = 0.1f,
            SpeedMin = 10,
            SpeedMax = 20,
            LifeMin = 1f,
            LifeMax = 3f,
            FadeMode = ParticleType.FadeModes.None,
            Friction = 0.1f
        };
        private ParticleType P_Respawn = new ParticleType
        {
            Source = GFX.Game["objects/PuzzleIslandHelper/particles/bubbleSmall"],
            SpinMin = 0.3f,
            SpinMax = 1,
            Size = 0.4f,
            SpeedMin = 50,
            SpeedMax = 50,
            LifeMin = 0.6f,
            LifeMax = 0.6f,
            FadeMode = ParticleType.FadeModes.Late,
        };
        private Color BubbleColor = Color.White;
        public BubbleType Type;
        public int Layers = 1;
        private Player player;
        public static readonly float NormalSpeed = 80f;
        public static readonly float DashSpeed = 130f;
        public static readonly Vector2 playerOffset = new Vector2(0, 2);
        private Sprite Sprite;
        private Image Flash;
        private float FlashMult = 0;
        public bool Moving;
        public Action OnRemoved;
        private Vector2 AimDir = Vector2.Zero;
        private float Speed
        {
            get
            {
                return baseSpeed - speedDecrease;
            }
        }
        private float baseSpeed;
        private bool popping;
        private bool popped;
        private float xOffset = 0;
        private float yOffset = 0;
        private float speedLerp = 1;
        private bool PassThru;
        private float AimXMult;
        private float AimYMult;
        public const float JumpHeight = 150f;
        private Tween JumpTween;
        private int Jumps = 3;
        private float JumpOffset;
        private float jumpTimer = jumpDelay;
        private const float jumpDelay = 0.1f;
        private SineWave floatDown;
        private bool Respawns;
        private Vector2 _pos;
        private int _layers;
        private bool Respawning;
        private Wiggler wiggler;
        private float scaleMult = 1;
        private float jumpScale = 0;
        private bool InWater
        {
            get
            {
                return CollideCheck<Water>();
            }
        }
        private float speedDecrease = 0f;
        private const float Slowed = 50f;
        public Bubble(EntityData data, Vector2 offset)
        : this(data.Position + offset, false, data.Int("layers", 1),
               data.Enum<BubbleType>("bubbleType"), data.Bool("noCollision"), data.Bool("respawns"))
        {

        }
        public Bubble(Vector2 position, bool immediate, int layers, BubbleType type, bool passThroughSolids = false, bool respawns = false) : base(position)
        {

            _pos = position;
            Moving = immediate;
            Respawns = respawns;
            Layers = _layers = layers;
            Type = type;
            PassThru = passThroughSolids;

            Depth = -9999;
            Collider = new Hitbox(28, 28, 2, 2);
            BubbleColor = type switch
            {
                BubbleType.Straight => Color.White,
                BubbleType.FullControl => Color.OrangeRed,
                BubbleType.FloatDown => Color.DeepPink,
                _ => Color.White
            };
            AimXMult = type switch
            {
                BubbleType.FullControl => 1,
                BubbleType.FloatDown => 0.7f,
                _ => 1
            };
            AimYMult = type switch
            {
                BubbleType.FullControl => 1,
                BubbleType.FloatDown => 1f,
                _ => 1
            };
            CreateSprites();
            Add(new VertexLight(Color.White, 1f, 16, 32));
            Add(new BloomPoint(0.1f, 16f));
            Add(wiggler = Wiggler.Create(0.5f, 4f, delegate (float f)
            {
                scaleMult = (1f + f * 0.25f);
            }));
            Add(new DashListener(OnPlayerDashed));
            Add(new MirrorReflection());

            Add(new PlayerCollider(OnPlayer));
        }
        public void OnPlayerDashed(Vector2 direction)
        {
            if (Moving)
            {
                if (InWater)
                {
                    StartMove(player);
                }
                else
                {
                    Pop();
                }
            }
        }
        private void Respawn()
        {
            Respawning = false;
            Flash.Scale.Y = Sprite.Scale.Y = 1;
            FlashMult = 1;
            Flash.Color = BubbleColor * FlashMult;
            JumpOffset = 0;
            jumpTimer = 0;
            speedLerp = 1;
            xOffset = 0;
            yOffset = 0;
            Sprite.Visible = true;
            Sprite.Play("idle");
            Flash.Visible = true;
            Collidable = true;
            Position = _pos;
            Layers = _layers;
            Jumps = 3;
            Moving = false;
            popping = false;
            popped = false;
            wiggler.Start();
            for (float j = 0; j <= 360; j += 45)
            {
                PianoModule.Session.BubbleSystem.Emit(P_Respawn, 1, Center, Vector2.Zero, BubbleColor, j.ToRad());
            }
        }
        private IEnumerator RespawnRoutine()
        {
            yield return 0.1f;
            if (!Respawning)
            {
                Respawning = true;
                Sprite.Visible = false;
                Flash.Visible = false;
                Collidable = false;
                Moving = false;
                yield return 4f;
                Respawn();
            }
        }
        private void CreateSprites()
        {
            Add(Sprite = new Sprite(GFX.Game, "objects/PuzzleIslandHelper/bubble/"));
            Sprite.AddLoop("idle", "bubble", 0.1f);
            Sprite.Add("pop", "bubblePop", 0.1f);
            Sprite.CenterOrigin();
            Sprite.Position += new Vector2(Sprite.Width / 2, Sprite.Height / 2);
            Sprite.Play("idle");
            Sprite.Color = BubbleColor;

            Sprite.OnFinish = (string s) =>
                {
                    if (s == "pop")
                    {
                        popped = true;
                        if (Respawns)
                        {
                            Add(new Coroutine(RespawnRoutine()));
                        }
                        else
                        {
                            RemoveSelf();
                        }

                    }
                };

            Add(Flash = new Image(GFX.Game["objects/PuzzleIslandHelper/bubble/solid"]));
            Flash.Color = BubbleColor * 0;
            Flash.CenterOrigin();
            Flash.Position += new Vector2(Flash.Width / 2, Flash.Height / 2);
        }
        public void OnPlayer(Player player)
        {
            if (!Moving && !Respawning)
            {
                StartMove(player);
            }
            if (Moving && player.CollideAll<Bubble>().Count > 1)
            {
                Pop();
            }
        }
        public override void Render()
        {
            base.Render();
        }
        private void TrailParticles()
        {
            if (player != null)
            {
                PianoModule.Session.BubbleSystem.Emit(P_Trail, 1, player.Center - Vector2.UnitY * 4, Vector2.One, BubbleColor * 0.2f);
                PianoModule.Session.BubbleSystem.Emit(P_Trail, 1, player.Center + Vector2.UnitY * 4, Vector2.One, BubbleColor * 0.2f);
            }
        }
        private void JumpParticles()
        {

            PianoModule.Session.BubbleSystem.Emit(P_Jump, 1, BottomRight, Vector2.Zero, BubbleColor * 0.7f, 45f.ToRad());
            PianoModule.Session.BubbleSystem.Emit(P_Jump, 1, BottomCenter, Vector2.Zero, BubbleColor * 0.7f, 90f.ToRad());
            PianoModule.Session.BubbleSystem.Emit(P_Jump, 1, BottomLeft, Vector2.Zero, BubbleColor * 0.7f, 135f.ToRad());

        }
        private void PopParticles()
        {

            for (float j = 0; j <= 360; j += 45)
            {
                PianoModule.Session.BubbleSystem.Emit(P_Pop, 1, PianoUtils.RotatePoint(Center + Vector2.One * 6, Center, j), Vector2.One * 0.5f, BubbleColor, j.ToRad());
            }

        }
        public override void Awake(Scene scene)
        {
            base.Awake(scene);
            if (PianoUtils.SeekController<BubbleParticleSystem>(scene) == null)
            {
                scene.Add(PianoModule.Session.BubbleSystem = new BubbleParticleSystem(0, 500));
            }
            player = scene.Tracker.GetEntity<Player>();
            JumpTween = Tween.Create(Tween.TweenMode.Oneshot, Ease.QuintOut, 1);
            JumpTween.OnStart = delegate { JumpOffset = JumpHeight; jumpScale = 0.80f; };
            JumpTween.OnUpdate = (Tween t) =>
            {
                JumpOffset = Calc.LerpClamp(JumpHeight, 0, t.Eased);
            };
            Add(JumpTween);
            if (Moving && player != null)
            {
                StartMove(player);
            }

        }
        private void StartMove(Player player)
        {
            bool dashing = player.StateMachine.State == Player.StDash || player.StartedDashing || player.DashAttacking;
            player.DummyAutoAnimate = false;
            player.DummyGravity = false;
            AimDir = dashing ? player.DashDir : Vector2.Normalize(player.Speed);
            baseSpeed = dashing ? DashSpeed : NormalSpeed;
            if (Type == BubbleType.FloatDown)
            {
                Add(new Coroutine(SpeedRoutine()));
            }
            wiggler.Start();

            Moving = true;
        }
        private void AdjustValues()
        {
            jumpScale = Calc.Approach(jumpScale, 0, Engine.DeltaTime * 1f);
            Flash.Scale = Sprite.Scale = Vector2.One * scaleMult - Vector2.UnitY * jumpScale;
            FlashMult = Calc.Approach(FlashMult, 0, Engine.DeltaTime * 2);
            Flash.Color = BubbleColor * FlashMult;
            speedDecrease = Calc.Approach(speedDecrease, InWater ? Slowed : 0, 2);
            if (Moving)
            {
                JumpOffset = Calc.Approach(JumpOffset, 0, 450f * Engine.DeltaTime);
                jumpTimer += Engine.DeltaTime;

                if (Type != BubbleType.Straight)
                {
                    AimDir.X = Calc.Approach(AimDir.X, Input.MoveX.Value * AimXMult, Engine.DeltaTime);
                    AimDir.Y = Calc.Approach(AimDir.Y, Input.MoveY.Value * AimYMult, Engine.DeltaTime);
                }
            }
        }
        public override void Update()
        {
            if (Scene is not Level level)
            {
                return;
            }
            AdjustValues();
            if (Moving)
            {
                if (player != null)
                {
                    if (player.Dead)
                    {
                        if (!popping)
                        {
                            Sprite.Scale.Y = 1;
                            Sprite.Play("pop");
                            Pop();
                        }
                        base.Update();
                        return;
                    }
                    if (!popping)
                    {
                        if (!popped)
                        {
                            if (jumpTimer > jumpDelay && Input.Jump.Pressed)
                            {
                                jumpTimer = 0;
                                Jump();
                            }
                        }
                        TypeMethod(Type).Invoke(player);
                    }

                    if (PassThru)
                    {
                        NoCollisionUpdate(player);
                    }

                    PlayerUpdate(player);
                }
            }
            base.Update();
            if (Moving && !popping && !popped)
            {
                player.Sprite.Scale = Vector2.One;
                if (Scene.OnInterval(10f / 60f)) TrailParticles();
            }
        }
        public void FloatDownUpdate(Player player)
        {
            float x = ((Speed * AimDir.X * speedLerp) + xOffset) * Engine.DeltaTime;
            float y = ((Speed * AimDir.Y * speedLerp) + yOffset - JumpOffset) * Engine.DeltaTime;
            MoveH(x, OnCollideH);
            MoveV(y, OnCollideV);
        }
        public void FullControlUpdate(Player player)
        {
            MoveH(Speed * AimDir.X * Engine.DeltaTime, OnCollideH);
            MoveV((Speed * AimDir.Y - JumpOffset) * Engine.DeltaTime, OnCollideV);
        }
        public void NoCollisionUpdate(Player player)
        {
            if (Moving)
            {
                player.DummyAutoAnimate = false;
                player.DummyGravity = false;
                player.Collidable = false;
            }
            else if (popping || popped)
            {
                player.Collidable = true;
                if (!player.Dead && player.CollideCheck<Solid>())
                {
                    player.Die(AimDir);
                }
            }
        }
        public void StraightUpdate(Player player)
        {
            MoveH(Speed * AimDir.X * Engine.DeltaTime, OnCollideH);
            MoveV((Speed * AimDir.Y - JumpOffset) * Engine.DeltaTime, OnCollideV);
        }
        private void Jump()
        {
            if (Jumps > 0)
            {
                jumpScale = 0.4f;
                Jumps--;
                JumpOffset = JumpHeight;
                FlashMult = 1;
                JumpParticles();
            }
            else
            {
                Pop();
            }
        }
        private void PlayerUpdate(Player player)
        {
            if (!popping && !popped)
            {

                Vector2 vector2 = new Vector2((int)Center.X - (int)player.Collider.Center.X + (int)playerOffset.X, (int)Center.Y - (int)player.Collider.Center.Y + (int)playerOffset.Y);
                player.RefillDash();
                player.RefillStamina();

                player.MoveTowardsX((int)Math.Round(vector2.X), Speed);
                player.MoveTowardsY((int)Math.Round(vector2.Y), Speed);

            }
            else if (!popped)
            {
                popped = true;
                player.DummyAutoAnimate = true;
                if (!player.DashAttacking || Jumps <= 0)
                {
                    player.Bounce(player.Center.Y);
                }
                Sprite.Play("pop");
            }
        }
        public override void Removed(Scene scene)
        {
            base.Removed(scene);
            Player player = scene.Tracker.GetEntity<Player>();
            if (player != null)
            {
                player.StateMachine.State = Player.StNormal;
            }
            OnRemoved?.Invoke();
        }
        private void OnCollideH(CollisionData data)
        {
            if (data.Hit is Solid && !PassThru)
            {
                BreakLayer();
            }
        }
        private void Pop()
        {
            popping = true;
            Player player = Scene.Tracker.GetEntity<Player>();
            if (player != null && !player.DashAttacking)
            {
                SceneAs<Level>().Displacement.AddBurst(Center, 0.2f, 8f, 32f, 0.4f, Ease.QuadOut, Ease.QuadOut);
            }
            P_Pop.Acceleration = new Vector2(Speed * AimDir.X, Speed * AimDir.Y) * Engine.DeltaTime;
            PopParticles();
        }
        private void BreakLayer()
        {
            Layers--;
            if (Layers <= 0)
            {
                Moving = false;
                Pop();
            }
        }
        private void OnCollideV(CollisionData data)
        {
            if (data.Hit is Solid && !PassThru)
            {
                BreakLayer();
            }
        }
        public Action<Player> TypeMethod(BubbleType type)
        {
            return type switch
            {
                BubbleType.FloatDown => FloatDownUpdate,
                BubbleType.FullControl => FullControlUpdate,
                BubbleType.Straight => StraightUpdate,
                _ => StraightUpdate
            };
        }
        private IEnumerator FloatDown()
        {
            yOffset = 30f;
            floatDown = new SineWave(1);
            Add(floatDown);
            while (true)
            {
                xOffset = (int)Math.Round(floatDown.Value * 44);
                yield return null;
            }
        }
        private IEnumerator SpeedRoutine()
        {
            float duration = 3;
            bool added = false;
            for (float i = 0; i < duration; i += Engine.DeltaTime)
            {
                speedLerp = 1 - Ease.SineOut(i / duration);
                yield return null;
                if (i > duration - (duration / 3f) && !added)
                {
                    added = true;
                    Add(new Coroutine(FloatDown()));
                }
            }
        }
    }
}
