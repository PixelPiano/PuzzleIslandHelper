﻿
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monocle;


namespace Celeste.Mod.PuzzleIslandHelper.Entities.DEBUG
{
    [CustomEntity("PuzzleIslandHelper/TEST")]
    [Tracked]
    public class TEST : Entity
    {

        public float[] Floats;
        public string StringA;
        public string StringB;
        public bool[] Bools;
        public Color Color;

        private VirtualRenderTarget Target;
        private VirtualRenderTarget Mask;

        private bool inBounds;
        public TEST(EntityData data, Vector2 offset) : base(data.Position + offset)
        {
            Floats = new float[] { data.Float("numA"), data.Float("numB"), data.Float("numC"), data.Float("numD") };
            Bools = new bool[] { data.Bool("boolA"), data.Bool("boolB"), data.Bool("boolC") };
            StringA = data.Attr("stringA");
            StringB = data.Attr("stringB");
            Color = data.HexColor("color");
            Collider = new Hitbox(data.Width, data.Height);
            Target = VirtualContent.CreateRenderTarget("a", 320, 180);
            Mask = VirtualContent.CreateRenderTarget("b", (int)Width, (int)Height);
            Add(new BeforeRenderHook(BeforeRender));
        }
        private static BlendState t = new()
        {
            ColorSourceBlend = Blend.One,
            ColorBlendFunction = BlendFunction.ReverseSubtract,
            ColorDestinationBlend = Blend.One,
            AlphaSourceBlend = Blend.Zero,
            AlphaBlendFunction = BlendFunction.Add,
            AlphaDestinationBlend = Blend.Zero

        };
        private void BeforeRender()
        {
            Engine.Graphics.GraphicsDevice.SetRenderTarget(Target);
            Engine.Graphics.GraphicsDevice.Clear(Color.Transparent);
            if (!inBounds || Scene is not Level level || level.GetPlayer() is not Player player) return;
            Engine.Graphics.GraphicsDevice.SetRenderTarget(Mask);
            Engine.Graphics.GraphicsDevice.Clear(Color.Transparent);
            Draw.SpriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointWrap, DepthStencilState.None, RasterizerState.CullNone, null, Matrix.Identity);
            player.Position -= Position;
            player.Hair.MoveHairBy(-Position);
            player.Hair.Render();
            player.Render();
            player.Position += Position;
            player.Hair.MoveHairBy(Position);

            Draw.SpriteBatch.End();
            Engine.Graphics.GraphicsDevice.SetRenderTarget(Target);
            Draw.SpriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointWrap, DepthStencilState.None, RasterizerState.CullNone, null, level.Camera.Matrix);

            player.Render();

            Draw.SpriteBatch.End();

            Draw.SpriteBatch.Begin(SpriteSortMode.Deferred, t, SamplerState.PointWrap, DepthStencilState.None, RasterizerState.CullNone, null, level.Camera.Matrix);
            Draw.SpriteBatch.Draw(Mask, Position, Color.White);
            Draw.SpriteBatch.End();
        }
        public override void Render()
        {
            base.Render();
            if (Scene is Level level)
            {
                Draw.SpriteBatch.Draw(Target, level.Camera.Position, Color);
            }

        }
        public override void Update()
        {
            base.Update();
            if (Scene is Level level && level.GetPlayer() is Player player)
            {
                bool colliding = CollideCheck<Player>();
                if (player.Visible)
                {
                    if (colliding)
                    {
                        player.Visible = false;
                        inBounds = true;
                    }
                }
                else
                {
                    if (!colliding)
                    {
                        player.Visible = true;
                        inBounds = false;
                    }
                }
            }
        }
        public override void Removed(Scene scene)
        {
            base.Removed(scene);
            Target?.Dispose();
            Mask?.Dispose();
            Target = Mask = null;
        }

    }
}
