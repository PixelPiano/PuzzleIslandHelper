﻿using Celeste.Mod.CommunalHelper;
using Celeste.Mod.Entities;
using Celeste.Mod.PuzzleIslandHelper.Components.Visualizers;
using Celeste.Mod.PuzzleIslandHelper.Components.Visualizers.DSPs;
using Microsoft.Xna.Framework;
using Monocle;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Celeste.Mod.PuzzleIslandHelper.Entities.DEBUG
{
    [CustomEntity("PuzzleIslandHelper/osc")]
    [Tracked]
    public class Osc : Entity
    {
        public float[] Floats;
        public string StringA;
        public string StringB;
        public bool[] Bools;
        public Color Color;
        public FFT FFT;
        public AudioEffect Sound;
        public bool Injected => FFT is not null && FFT.Injected;
        public float[][] Spectrum => FFT is null ? null : FFT.Spectrum;
        public bool SpectrumExists => Spectrum is not null;
        public bool SpectrumIsPopulated => SpectrumExists && FFT.Spectrum.Length > 0 && FFT.Spectrum[0].Length >= 0;
        public Vector2[] Signal;
        public Vector2 MaxPoint;

        public List<Vector2> Output = new();
        public float XOffset;
        public Osc(EntityData data, Vector2 offset) : base(data.Position + offset)
        {
            Floats = new float[] { data.Float("numA"), data.Float("numB"), data.Float("numC"), data.Float("numD") };
            Bools = new bool[] { data.Bool("boolA"), data.Bool("boolB"), data.Bool("boolC") };
            StringA = data.Attr("stringA");
            StringB = data.Attr("stringB");
            Color = data.HexColor("color");
            Collider = new Hitbox(data.Width, data.Height);
            FFT = new FFT(8000);

            Sound = new AudioEffect(FFT);
            Add(Sound);
            Add(new Coroutine(Routine()));
        }
        public IEnumerator Routine()
        {
            string[] waves = new string[] { "saw", "sine", "square", "tri" };
            while (true)
            {
                for (int i = 0; i < 4; i++)
                {
                    Sound.PlayEvent("event:/PianoBoy/Soundwaves/" + waves[i]);
                    Output.Clear();
                    while (Sound.Playing)
                    {
                        yield return null;
                    }
                    yield return 0.1f;
                }
            }
        }
        public override void Update()
        {
            base.Update();
            Output.Clear();
            if (!SpectrumExists || !SpectrumIsPopulated || !Sound.Playing) return;
            Signal = CreateSignal(Spectrum[0], FFT.DominantFreq, 0.01f);
        }
        private void DrawSignal(Vector2[] signal, Vector2 position)
        {
            if (!Sound.Playing) return;
            Vector2 offset = position + Vector2.UnitY * (Height - 1);
            Vector2 s = new Vector2(Width / signal.Length, -Height);
            for (int i = 1; i < signal.Length; i++)
            {
                Vector2 signalA = signal[i - 1].Abs();
                Vector2 signalB = signal[i].Abs();
                Vector2 start = offset + signalA * s;
                Vector2 end = offset + signalB * s;
                DrawCurve(start, (start + end) / 2, Vector2.UnitY * -4);
                DrawCurve((start + end) / 2, end, Vector2.UnitY * 4);
                Draw.Line(start, end, Color.White);
            }

        }
        private Vector2[] CreateSignal(float[] spectrum, float freq, float threshold)
        {
            List<Vector2> signal = new();
            int index = 0;
            while (index < spectrum.Length && signal.Count < Width)
            {
                if(spectrum[index] <= threshold)
                {
                    index++;
                    continue;
                }
                float wave = (float)(spectrum[index] * Math.Cos(2 * Math.PI * freq * Sound.TimePlaying));
                signal.Add(new Vector2(index, wave));
                index++;
            }
            return signal.ToArray();
        }
        public void DrawCurve(Vector2 from, Vector2 to, Vector2 control)
        {
            from = from.Round();
            to = to.Round();
            SimpleCurve curve = new SimpleCurve(from, to, (from + to) / 2f + control);
            Vector2 vector = curve.Begin;
            int steps = (int)Vector2.Distance(from, to);
            for (int j = 1; j <= steps; j++)
            {
                float percent = (float)j / steps;
                Vector2 point = curve.GetPoint(percent).Round();
                Draw.Line(vector, point, Color.White);
                vector = point + (vector - point).SafeNormalize();
            }
        }
        public override void Render()
        {
            base.Render();
            Draw.Rect(Collider, Color.Black);
            if (Signal is null) return;
            DrawSignal(Signal, Position);
        }
    }
}
