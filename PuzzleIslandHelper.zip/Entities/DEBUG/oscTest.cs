﻿using Celeste.Mod.PuzzleIslandHelper.Components.Visualizers;
using Microsoft.Xna.Framework;
using Monocle;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Celeste.Mod.PuzzleIslandHelper.Entities.DEBUG
{
    [Tracked]
    public class oscTest : Entity
    {
        public float[] Floats;
        public string StringA;
        public string StringB;
        public bool[] Bools;
        public Color Color;
        public AudioEffect Sound;
        public int WaveLength = 2;
        public float Space => Width / WaveLength;
        public float XOffset;
        public List<float> Output = new();
        public List<Vector2> Points = new();
        public oscTest(EntityData data, Vector2 offset) : base(data.Position + offset)
        {
            Floats = new float[] { data.Float("numA"), data.Float("numB"), data.Float("numC"), data.Float("numD") };
            Bools = new bool[] { data.Bool("boolA"), data.Bool("boolB"), data.Bool("boolC") };
            StringA = data.Attr("stringA");
            StringB = data.Attr("stringB");
            Color = data.HexColor("color");
            Collider = new Hitbox(data.Width, data.Height);

            Sound = new AudioEffect();
            Add(Sound);
        }
        public override void Added(Scene scene)
        {
            base.Added(scene);
            Add(new Coroutine(routine()));
        }
        private IEnumerator routine()
        {
            string[] waves = new string[] { "sine", "saw", "square", "triangle" };
            while (true)
            {
                foreach (string s in waves)
                {
                    Sound.PlayEvent("event:/PianoBoy/Soundwaves/" + s);
                    while (Sound.Playing)
                    {
                        yield return null;
                    }
                    yield return 0.5f;
                }
            }
        }
        public override void Update()
        {
            base.Update();
            if (Scene.OnInterval(3f / 60) && Sound.Playing)
            {
                GetBuffer(CenterLeft, 1, Height / 2, new Vector2(Width / Sound.BufferLength, 1));
            }
        }
        public void GetBuffer(Vector2 position, float spacing, float height, Vector2 scale)
        {
            height *= 2;
            Points.Clear();
            int perPixel = (int)Math.Max(Math.Floor(Sound.BufferLength / Width), 1);
            if (Sound is null || Sound.BufferLength <= 0) return;
            Vector2 prev = Vector2.Zero;
            Vector2 start = Vector2.Zero;
            for (int j = 0; j < Sound.BufferLength; j += perPixel)
            {
                start.X = j * spacing;
                start.Y = 0;
                for (int i = 0; i < Sound.Channels; i++)
                {
                    start.Y += Sound.DataBuffer[(j * Sound.Channels) + i] * height;
                }
                start.Y /= Sound.Channels;
                Points.Add(position + start * scale);
                prev = start;
            }
        }
        public override void Render()
        {
            base.Render();
            Draw.Rect(Collider, Color.Black);
            if (Sound.Playing)
            {
                for(int i = 1; i<Points.Count; i++)
                {
                    Draw.Line(Points[i-1],Points[i],Color.Green);
                }
               
            }
        }
    }
}
