local labReactor= {}
labReactor.justification = { 0, 0 }

labReactor.name = "PuzzleIslandHelper/LabReactor"

labReactor.depth = -8500

labReactor.texture = "objects/PuzzleIslandHelper/access/artifactHolder00"

labReactor.placements =
{
    {
        name = "Lab Reactor",
        data = 
        {
        }
    }
}

return labReactor