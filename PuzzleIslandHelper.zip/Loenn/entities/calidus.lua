local calidus= {}

calidus.name = "PuzzleIslandHelper/Calidus"
calidus.depth = 0

calidus.texture = "characters/PuzzleIslandHelper/Calidus/lonn"

calidus.placements =
{
    {
        name = "Calidus",
        data = 
        {
        }
    }
}

return calidus