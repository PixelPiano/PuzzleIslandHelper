local interface= {}
interface.justification = { 0, 0 }

interface.name = "PuzzleIslandHelper/Interface"

interface.depth = 0

interface.texture = "objects/PuzzleIslandHelper/interface/interface00"

interface.placements =
{
    {
        name = "Computer Interface",
        data = 
        {
            instance = 0,
            teleportTo = "4t",
            flipX = false
        }
    }
}

return interface