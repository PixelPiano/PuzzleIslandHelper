local artifactSlot= {}
artifactSlot.justification = { 0, 0 }

artifactSlot.name = "PuzzleIslandHelper/PuzzleIslandSkinSetter"

artifactSlot.depth = -8500

artifactSlot.texture = "objects/PuzzleIslandHelper/access/artifactHolder00"

artifactSlot.placements =
{
    {
        name = "PI Skin Setter",
        data = 
        {
        }
    }
}

return artifactSlot