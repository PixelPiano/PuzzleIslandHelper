local computerAccess = {}
computerAccess.justification = { 0, 0 }

computerAccess.name = "PuzzleIslandHelper/ComputerAccess"

computerAccess.depth = -8500

computerAccess.texture = "objects/PuzzleIslandHelper/access/artifact03"

computerAccess.placements =
{
    {
        name = "Computer Access",
        data = {}
    }
}

return computerAccess