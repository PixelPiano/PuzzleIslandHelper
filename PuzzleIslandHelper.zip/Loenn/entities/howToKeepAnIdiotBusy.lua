local _q = {}
_q.justification = { 0, 0 }

_q.name = "PuzzleIslandHelper/HowToKeepAnIdiotBusy"

_q.depth = -8500

_q.texture = "objects/PuzzleIslandHelper/chandelier/icons/default00"

_q.placements =
{
    {
        name = "HowToKeepAnIdiotBusy",
        data = {
        flag = "hi_carl"
        }
    }
}

return _q