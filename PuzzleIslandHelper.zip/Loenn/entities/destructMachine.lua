local _q = {}
_q.justification = { 0, 0 }

_q.name = "PuzzleIslandHelper/DestructMachine"

_q.depth = 10000

_q.texture = "objects/PuzzleIslandHelper/decisionMachine/machineBlue00"

_q.placements =
{
    {
        name = "Destruct Machine",
        data = 
        {
        }
    }
}

return _q