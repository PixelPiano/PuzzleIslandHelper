local powerLight= {}
powerLight.justification = {0.5, 1}
powerLight.name = "PuzzleIslandHelper/PowerLight"

powerLight.depth = -8500

powerLight.texture = "objects/PuzzleIslandHelper/decisionMachine/missingLight"

powerLight.placements =
{
    {
        name = "Power Light",
        data = 
        {
        }
    }
}

return powerLight