local destruct= {}
destruct.justification = { 0, 0 }

destruct.name = "PuzzleIslandHelper/Destruct"

destruct.depth = -8500

destruct.texture = "objects/PuzzleIslandHelper/interface/interface00"

destruct.placements =
{
    {
        name = "Computer Destruct",
        data = 
        {
            flipX = false
        }
    }
}

return destruct