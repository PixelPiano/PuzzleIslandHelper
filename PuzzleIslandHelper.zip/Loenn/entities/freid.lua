local freid= {}

freid.name = "PuzzleIslandHelper/Freid"
freid.depth = 0

freid.texture = "characters/PuzzleIslandHelper/Freid/lonn"

freid.placements =
{
    {
        name = "Freid",
        data = 
        {
        }
    }
}

return freid