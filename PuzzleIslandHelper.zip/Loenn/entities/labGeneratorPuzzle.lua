local labGeneratorPuzzle = {}
labGeneratorPuzzle.justification = { 0, 0 }

labGeneratorPuzzle.name = "PuzzleIslandHelper/LabGeneratorPuzzle"

labGeneratorPuzzle.depth = 10000

labGeneratorPuzzle.texture = "objects/PuzzleIslandHelper/decisionMachine/puzzle/placeholder"

labGeneratorPuzzle.placements =
{
    {
        name = "Lab Generator Puzzle",
        data = 
        {
        }
    }
}

return labGeneratorPuzzle