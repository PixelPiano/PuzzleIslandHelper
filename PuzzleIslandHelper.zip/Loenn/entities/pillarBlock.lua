local _q = {}
_q.justification = { 0, 0 }

_q.name = "PuzzleIslandHelper/PillarBlock"

_q.depth = -8500

_q.texture = "objects/PuzzleIslandHelper/pillarBlock/block00"

_q.placements =
{
    {
        name = "Pillar Block",
        data = {
        }
    }
}

return _q