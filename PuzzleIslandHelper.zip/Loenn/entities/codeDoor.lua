local codeDoor = {}
codeDoor.justification = { 0, 0 }

codeDoor.name = "PuzzleIslandHelper/CodeDoor"

codeDoor.depth = -1

codeDoor.texture = "objects/PuzzleIslandHelper/machineDoor/codeIdle00"

codeDoor.placements =
{
    name = "Code Door",
    data = 
    {
        flag = ""
    }
    
}

return codeDoor