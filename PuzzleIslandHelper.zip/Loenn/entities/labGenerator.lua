local labGenerator = {}
labGenerator.justification = { 0, 0 }

labGenerator.name = "PuzzleIslandHelper/LabGenerator"

labGenerator.depth = 10000

labGenerator.texture = "objects/PuzzleIslandHelper/decisionMachine/generator"

labGenerator.placements =
{
    {
        name = "Lab Generator",
        data = 
        {
        }
    }
}

return labGenerator