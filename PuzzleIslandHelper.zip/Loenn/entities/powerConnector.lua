local powerConnector= {}
powerConnector.justification = {0.5, 1}
powerConnector.name = "PuzzleIslandHelper/PowerConnector"

powerConnector.depth = -8500

powerConnector.texture = "objects/PuzzleIslandHelper/decisionMachine/connector"

powerConnector.placements =
{
    {
        name = "Power Connector",
        data = 
        {
        }
    }
}

return powerConnector