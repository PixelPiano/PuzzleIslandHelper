local artifactSlot= {}
artifactSlot.justification = { 0, 0 }

artifactSlot.name = "PuzzleIslandHelper/FluidMachine"

artifactSlot.depth = -8500

artifactSlot.texture = "objects/PuzzleIslandHelper/access/artifactHolder00"

artifactSlot.placements =
{
    {
        name = "Fluid Machine",
        data = 
        {
        }
    }
}

return artifactSlot