local eightSwitch = {}
eightSwitch.justification = { 0, 0 }

eightSwitch.name = "PuzzleIslandHelper/EightSwitch"

eightSwitch.depth = -8500

eightSwitch.texture = "objects/PuzzleIslandHelper/eightSwitch/lonn"

eightSwitch.placements =
{
    {
        name = "Eight Switch",
        data = {}
    }
}

return eightSwitch