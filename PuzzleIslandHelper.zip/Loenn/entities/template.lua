local _q = {}
_q.justification = { 0, 0 }

_q.name = "PuzzleIslandHelper/_q"

_q.depth = -8500

_q.texture = "objects/PuzzleIslandHelper/_q/lonn"

_q.placements =
{
    {
        name = "Eight Switch",
        data = {}
    }
}

return _q