local flipPuzzle = {}
flipPuzzle.justification = { 0, 0 }

flipPuzzle.name = "PuzzleIslandHelper/FlipPuzzle"

flipPuzzle.depth = -8500

flipPuzzle.texture = "objects/PuzzleIslandHelper/flipPuzzle/lonn"

flipPuzzle.placements =
{
    {
        name = "Flip Puzzle",
        data = {}
    }
}

return flipPuzzle