local _q = {}
_q.justification = { 0, 0 }

_q.name = "PuzzleIslandHelper/IconHolder"

_q.depth = -8500

_q.texture = "objects/PuzzleIslandHelper/chandelier/mainModule00"

_q.placements =
{
    {
        name = "Icon Holder",
        data = {}
    }
}

return _q