local artifactTester= {}
artifactTester.justification = { 0, 0 }

artifactTester.name = "PuzzleIslandHelper/ArtifactTester"

artifactTester.depth = -1

artifactTester.texture = "objects/PuzzleIslandHelper/artifactTester/monitor00"

artifactTester.placements =
{
    {
        name = "Artifact Tester",
        data = 
        {
        }
    }
}

return artifactTester