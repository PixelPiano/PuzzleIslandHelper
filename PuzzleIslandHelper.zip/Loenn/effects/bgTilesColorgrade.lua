local bgTilesColorgrade = {}

bgTilesColorgrade.name = "PuzzleIslandHelper/BgTilesColorgrade"

bgTilesColorgrade.defaultData = 
{
   colorgrade = "golden"
}

return bgTilesColorgrade