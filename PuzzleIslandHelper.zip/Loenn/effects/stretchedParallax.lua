local colorgradeOverlay = {}

colorgradeOverlay.name = "PuzzleIslandHelper/StretchedParallax"

colorgradeOverlay.defaultData = 
{
	flag = "",
	path = "bg/PuzzleIsland/labBgBBig"
}

return colorgradeOverlay