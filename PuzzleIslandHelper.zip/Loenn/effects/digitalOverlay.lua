local digitalEffect = {}

digitalEffect.name = "PuzzleIslandHelper/DigitalOverlay"

digitalEffect.defaultData =
{
    lineFlicker = true,
    backFlicker = true,
    leaveOutHair = true
}
return digitalEffect
