local blockGlitch = {}

blockGlitch.name = "PuzzleIslandHelper/BlockGlitch"

blockGlitch.defaultData = 
{
}

return blockGlitch