local invertOverlay = {}

invertOverlay.name = "PuzzleIslandHelper/InvertOverlay"

invertOverlay.defaultData = 
{
   colorgradeFlag = "colorgrade_overlay",
   timeMod = 0.5
}

return invertOverlay