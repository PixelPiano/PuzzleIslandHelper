local lampRenderer = {}

lampRenderer.name = "PuzzleIslandHelper/LampRenderer"

lampRenderer.defaultData = 
{
}

return lampRenderer