local parallaxWindow = {}

parallaxWindow.name = "PuzzleIslandHelper/ParallaxWindow"

parallaxWindow.defaultData = 
{
	flag = "",
}

return parallaxWindow