local roomLight = {}

roomLight.name = "PuzzleIslandHelper/RoomLight"

roomLight.placements =
{
    {
        name = "Room Light",
        data = {
        }
    },
}

return roomLight