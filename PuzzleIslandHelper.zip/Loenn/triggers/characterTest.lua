local fadeWarpTrigger = {}

fadeWarpTrigger.name = "PuzzleIslandHelper/CharacterTest"

fadeWarpTrigger.placements =
{
    {
        name = "Character Test",
        data = {
            testFloat = 1.5
        }
    },
}

return fadeWarpTrigger