local fadeWarpTrigger = {}

fadeWarpTrigger.name = "PuzzleIslandHelper/FadeWarpTrigger"

fadeWarpTrigger.placements =
{
    {
        name = "PI Wipe Trigger",
        data = {
        roomName = "",
        usesTarget = false,
        targetId = "Target",
        }
    },
}

return fadeWarpTrigger