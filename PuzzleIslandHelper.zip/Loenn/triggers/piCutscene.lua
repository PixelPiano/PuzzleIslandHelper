local piCutscene = {}

piCutscene.name = "PuzzleIslandHelper/PICutscene"

piCutscene.placements =
{
    {
        name = "Puzzle Island Cutscene",
        data = {
        cutscene = 0,
        oncePerRoom = false,
        oncePerPlaythrough = false,
        activateOnTransition = false
        }
    },
}

return piCutscene