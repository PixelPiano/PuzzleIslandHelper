local piCutscene = {}

piCutscene.name = "PuzzleIslandHelper/DigiMeet"

piCutscene.placements =
{
    {
        name = "Digi Meet",
        data = {
        }
    },
}

return piCutscene