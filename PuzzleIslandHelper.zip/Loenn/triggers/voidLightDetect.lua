local voidLightDetect = {}

voidLightDetect.name = "PuzzleIslandHelper/VoidLightDetect"

voidLightDetect.placements =
{
    {
        name = "Void Light Detect",
        data = {
        }
    },
}

return voidLightDetect