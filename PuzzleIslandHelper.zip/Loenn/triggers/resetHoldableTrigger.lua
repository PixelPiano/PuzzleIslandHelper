local resetHoldableTrigger = {}

resetHoldableTrigger.name = "PuzzleIslandHelper/ResetHoldableTrigger"

resetHoldableTrigger.placements =
{
    {
        name = "Reset Holdable Trigger",
        data = {
        }
    },
}

return resetHoldableTrigger