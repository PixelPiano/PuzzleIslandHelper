local invertCutsceneTrigger = {}

invertCutsceneTrigger.name = "PuzzleIslandHelper/InvertCutsceneTrigger"

invertCutsceneTrigger.placements =
{
    {
        name = "Invert Cutscene Trigger",
        data = {
        }
    },
}

return invertCutsceneTrigger